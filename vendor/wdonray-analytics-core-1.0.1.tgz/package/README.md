# @wdonray/analytics-core

Human-only visitor analytics core. Shared by donray.dev,
hidezerocards.org, and patternspell.org.

Zero runtime dependencies. Two entry points:

- `@wdonray/analytics-core/server` — Node.js: visitor hashing, IP
  extraction, bot detection, path normalization, rate limiting.
- `@wdonray/analytics-core/client` — Browser: headless detection,
  scroll-gated engagement tracking.

## Install

```bash
npm install @wdonray/analytics-core
```

With `.npmrc`:

```
@wdonray:registry=https://npm.pkg.github.com
```

## Bot exclusion

Five layers, strongest last:

1. **UA blocklist** (`isBotUserAgent`) — crawlers, scrapers, HTTP
   clients, uptime monitors.
2. **Headless detection** (`isHeadlessBrowser`) — `navigator.webdriver`,
   missing `window.chrome`, legacy automation globals. When true, send
   nothing.
3. **Engagement gate** (`createEngagementTracker`) — fires once on
   first scroll. Only engaged visitors enter the unique-visitor set.
4. **Rate limiting** (`createRateLimiter`) — per-IP sliding window.

## Usage

```typescript
// Server (API route)
import {
  hashVisitor,
  clientIpFromHeaders,
  isBotUserAgent,
  normalizePath,
  UNIQUES_SK_V2,
} from '@wdonray/analytics-core/server';

const ip = clientIpFromHeaders(req.headers);
const ua = req.headers.get('user-agent') ?? '';
if (isBotUserAgent(ua)) return Response.json({ ok: true }); // silent drop

const path = normalizePath(body.path);
if (!path) return Response.json({ ok: false }, { status: 400 });

// Always count the page view; only count the visitor when engaged.
await incrementPageView(path);
if (body.engaged === true) {
  await addUniqueVisitor(path, hashVisitor(SALT, ip, ua));
}
```

```typescript
// Client (tracker component)
import {
  isHeadlessBrowser,
  createEngagementTracker,
} from '@wdonray/analytics-core/client';

if (!isHeadlessBrowser()) {
  sendBeacon('/api/track', { path }); // page view
  createEngagementTracker({
    onEngaged: () => sendBeacon('/api/track', { path, engaged: true }),
  }).start();
}
```

## Releases

Automated via semantic-release on merge to `main`. Use conventional
commits: `fix:` → patch, `feat:` → minor, `feat!:` → major.
